public class StringUtil {
    public static String getMiddleSubstring(String str1, String str2, int length) {
        // Concatenate the two strings
        String concatenated = str1.concat(str2);

        // Reverse the concatenated string
        StringBuilder reversedBuilder = new StringBuilder(concatenated).reverse();
        String reversed = reversedBuilder.toString();

        // Calculate the middle index
        int middleIndex = reversed.length() / 2;

        // Calculate the starting index for the substring
        int startIndex = middleIndex - length / 2;

        // Check for edge cases
        if (reversed.isEmpty() || length > concatenated.length()) {
            return "Invalid input or substring length is too large";
        } else if (startIndex < 0) {
            startIndex = 0;
        } else if (startIndex + length > reversed.length()) {
            startIndex = reversed.length() - length;
        }

        // Extract the middle substring
        String middleSubstring = reversed.substring(startIndex, startIndex + length);
        return middleSubstring;
    }

    public static void main(String[] args) {
        String str1 = "Hello";
        String str2 = "World";
        int length = 4;
        System.out.println(getMiddleSubstring(str1, str2, length)); // Output should be "orl"
    }
}