import java.util.Random;

public class BruteForceSort {

    public static void bruteForceSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // swap arr[j] and arr[j+1]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        int[] arrayToSort = initializeArray(10, 1, 100); // Example: initialize array of size 10 with values between 1 and 100
        System.out.println("Array before sorting:");
        printArray(arrayToSort);
        
        bruteForceSort(arrayToSort);
        
        System.out.println("Array after sorting:");
        printArray(arrayToSort);
    }

    // Helper method to initialize an array with random values within a given range
    public static int[] initializeArray(int size, int min, int max) {
        int[] arr = new int[size];
        Random rand = new Random();
        for (int i = 0; i < size; i++) {
            arr[i] = rand.nextInt(max - min + 1) + min;
        }
        return arr;
    }

    // Helper method to print an array
    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}