import java.util.Scanner;
public class ReverseArray {
    public static void main(String[] args) {
        // Declare and initialize an array of integers
        int[] numbers = new int[10];
        
        // Initialize the array with consecutive numbers
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = i + 1;
        }
        
        // Print the array in reverse order
        System.out.println("Original Array:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        
        System.out.println("\nArray in Reverse Order:");
        for (int i = numbers.length - 1; i >= 0; i--) {
            System.out.print(numbers[i] + " ");
        }
    }
}
