public class Recursivefunction{
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        int sum = sumArray(arr, arr.length);
        System.out.println("Sum of array elements: " + sum);
    }

    public static int sumArray(int[] arr, int n) {
        // Base case: if the array has only one element, return that element
        if (n == 1) {
            return arr[0];
        } else {
            // Recursive case: return the sum of the current element and the sum of the rest of the array
            return arr[n - 1] + sumArray(arr, n - 1);
        }
    }
}