import java.util.Arrays;

public class ArraySlicer {

    public static int[] sliceArray(int[] arr, int start, int end) {
        if (start < 0 || end > arr.length || start > end) {
            // Invalid input, return an empty array
            return new int[0];
        }

        int[] result = new int[end - start];
        int index = 0;
        for (int i = start; i < end; i++) {
            result[index] = arr[i];
            index++;
        }
        return result;
    }

    public static void main(String[] args) {
        int[] array = {9, 10, 13, 42, 25, 16, 27, 48, 69};
        int start = 2;
        int end = 6;

        int[] slicedArray = sliceArray(array, start, end);
        System.out.println("Original array: " + Arrays.toString(array));
        System.out.println("Sliced array from index " + start + " to " + end + ": " + Arrays.toString(slicedArray));
    }
}