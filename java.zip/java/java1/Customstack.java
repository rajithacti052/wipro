import java.util.EmptyStackException;

class CustomStack {
    private int[] stackArray;
    private int top;
    private int maxSize;

    public CustomStack(int size) {
        maxSize = size;
        stackArray = new int[maxSize];
        top = -1;
    }

    public void push(int value) {
        if (top < maxSize - 1) {
            stackArray[++top] = value;
        } else {
            System.out.println("Stack Overflow: Cannot push " + value + " as stack is full");
        }
    }

    public int pop() {
        if (!isEmpty()) {
            return stackArray[top--];
        } else {
            throw new EmptyStackException();
        }
    }

    public int peek() {
        if (!isEmpty()) {
            return stackArray[top];
        } else {
            throw new EmptyStackException();
        }
    }

    public boolean isEmpty() {
        return (top == -1);
    }
}

public class Main {
    public static void main(String[] args) {
        CustomStack stack = new CustomStack(5);

        // Push integers onto the stack
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.push(5);

        // Pop and display integers until the stack is empty
        while (!stack.isEmpty()) {
            System.out.println(stack.pop());
        }
    }
}