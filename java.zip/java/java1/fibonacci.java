public class fibonacci {

    public static int fibonacci(int n) {
        if (n <= 1) {
            return n;
        }
        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    public static int[] generateFibonacciArray(int n) {
        int[] fibonacciArray = new int[n];
        for (int i = 0; i < n; i++) {
            fibonacciArray[i] = fibonacci(i);
        }
        return fibonacciArray;
    }

    public static void main(String[] args) {
        int n = 20; // Change this to generate different Fibonacci sequences
        
        // Generate Fibonacci sequence
        int[] fibonacciSequence = generateFibonacciArray(n);

        // Print Fibonacci sequence
        System.out.println("Fibonacci sequence of length " + n + ":");
        for (int i = 0; i < n; i++) {
            System.out.print(fibonacciSequence[i] + " ");
        }
        
        // Find the nth Fibonacci number
        int nthElement = fibonacci(n - 1);
        System.out.println("\n" + n + "th Fibonacci number: " + nthElement);
    }
}