public class Main {
    public static void main(String[] args) {
        // Attempting to divide by zero
        try {
            int result = divideByZero(5, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Cannot divide by zero.");
        }
        
        // Using CustomQueue with strings and integers
        CustomQueue<Object> queue = new CustomQueue<>();
        queue.enqueue("Hello");
        queue.enqueue(42);
        queue.enqueue("World");
        
        while (!queue.isEmpty()) {
            System.out.println(queue.dequeue());
        }
    }
    
    public static int divideByZero(int numerator, int denominator) {
        return numerator / denominator;
    }
}

class CustomQueue<T> {
    private Node<T> head;
    private Node<T> tail;
    
    public CustomQueue() {
        head = null;
        tail = null;
    }
    
    public void enqueue(T data) {
        Node<T> newNode = new Node<>(data);
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
    }
    
    public T dequeue() {
        if (isEmpty()) {
            return null;
        } else {
            T data = head.data;
            head = head.next;
            return data;
        }
    }
    
    public T peek() {
        if (isEmpty()) {
            return null;
        } else {
            return head.data;
        }
    }
    
    public boolean isEmpty() {
        return head == null;
    }
    
    private static class Node<T> {
        private T data;
        private Node<T> next;
        
        public Node(T data) {
            this.data = data;
            this.next = null;
        }
    }
}