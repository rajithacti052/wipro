import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        List<Integer> myList = new ArrayList<>();
        myList.add(1);
        myList.add(2);
        myList.add(3);
        myList.add(4);
        myList.add(5);
        
        removeEverySecondElement(myList);
    }
    
    public static void removeEverySecondElement(List<?> list) {
        for (int i = list.size() - 1; i >= 0; i--) {
            if (i % 2 == 1) {
                list.remove(i);
            }
        }
        
        System.out.println("Resulting list after removing every second element:");
        System.out.println(list);
    }
}