import com.math.operations.*;

public class Main {
    public static void main(String[] args) {
        int a = 10;
        int b = 5;

        System.out.println("Addition: " + Addition.add(a, b));
        System.out.println("Subtraction: " + Subtraction.subtract(a, b));
        System.out.println("Multiplication: " + Multiplication.multiply(a, b));
        System.out.println("Division: " + Division.divide(a, b));
    }
}